Copy the icons of choice into this directory.

The names of the files have to be:

    searchTab.ico
    downloadsTab.ico
    uploadsTab.ico
    connectionsTab.ico
    sharedfilesTab.ico
    settingsTab.ico
    
NOTE:

Icons any larger than 32x32 will probably not look very good on the GUI.