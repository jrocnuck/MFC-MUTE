/*
 * Modification History
 *
 * 2002-October-18 Jason Rohrer
 * Created.
 */



#ifndef MINOR_GEMS_COMMON_INCLUDED
#define MINOR_GEMS_COMMON_INCLUDED



#include "minorGems/util/development/memory/debugMemory.h"



#endif
