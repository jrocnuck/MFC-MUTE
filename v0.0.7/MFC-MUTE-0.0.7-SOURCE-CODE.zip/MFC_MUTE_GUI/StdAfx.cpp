// stdafx.cpp : source file that includes just the standard includes
//	MFC_MUTE_GUI.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



unsigned int g_unStringLanguageIdOffset;
CStringArray strArray;  //  Global array for external strings resource 